package com.kelompok2sk1c.byteblaze;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ByteblazeApplicationTests {

	@Test
	void contextLoads() {
	}

}
