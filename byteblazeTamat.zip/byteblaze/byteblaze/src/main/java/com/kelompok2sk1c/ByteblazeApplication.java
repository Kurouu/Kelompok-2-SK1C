package com.kelompok2sk1c;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ByteblazeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ByteblazeApplication.class, args);
	}

}
