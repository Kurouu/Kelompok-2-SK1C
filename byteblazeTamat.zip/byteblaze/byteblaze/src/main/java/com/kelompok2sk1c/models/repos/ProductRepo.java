package com.kelompok2sk1c.models.repos;

import com.kelompok2sk1c.models.entities.Product;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


public interface ProductRepo extends CrudRepository<Product, Long> {

    List<Product> findByNameContains(String name);    
}
